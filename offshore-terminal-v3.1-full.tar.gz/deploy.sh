#!/bin/bash
# ============================================================
# Offshore Ops Terminal v3 — VPS Deploy Script
# Run on your Hetzner VPS
# ============================================================

set -e

APP_DIR="/opt/offshore-terminal"
GREEN='\033[0;32m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}=== OFFSHORE OPS TERMINAL v3 — DEPLOY ===${NC}"
echo ""

# 1. Ensure Node.js is installed
if ! command -v node &> /dev/null; then
    echo "Installing Node.js 20..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt-get install -y nodejs
fi

echo -e "${GREEN}✓ Node.js $(node --version)${NC}"

# 2. Install PM2 if needed
if ! command -v pm2 &> /dev/null; then
    echo "Installing PM2..."
    sudo npm install -g pm2
    pm2 startup systemd -u $USER --hp $HOME 2>/dev/null || true
fi

echo -e "${GREEN}✓ PM2 installed${NC}"

# 3. Create app directory
sudo mkdir -p $APP_DIR/logs $APP_DIR/data
sudo chown -R $USER:$USER $APP_DIR

# 4. Copy files (assumes you've already transferred files via scp/rsync)
if [ ! -f "$APP_DIR/package.json" ]; then
    echo ""
    echo "Files not found in $APP_DIR."
    echo "Transfer the project first:"
    echo ""
    echo "  # From your local machine:"
    echo "  rsync -avz --exclude node_modules --exclude dist --exclude data \\"
    echo "    ./offshore-terminal/ user@your-vps:$APP_DIR/"
    echo ""
    exit 1
fi

cd $APP_DIR

# 5. Install dependencies
echo "Installing dependencies..."
npm install --production=false

# 6. Build TypeScript
echo "Building..."
npm run build

# 7. Set up .env if not exists
if [ ! -f ".env" ]; then
    cp .env.example .env
    echo ""
    echo -e "${CYAN}⚠ Created .env from template. Edit it now:${NC}"
    echo "  nano $APP_DIR/.env"
    echo ""
    echo "At minimum, set:"
    echo "  - COINGLASS_API_KEY (if you have one)"
    echo "  - TELEGRAM_BOT_TOKEN + TELEGRAM_CHAT_ID (for alerts)"
    echo ""
fi

# 8. Start/restart with PM2
pm2 delete offshore-terminal 2>/dev/null || true
pm2 start ecosystem.config.js
pm2 save

echo ""
echo -e "${GREEN}=== DEPLOYED ===${NC}"
echo ""
echo "Dashboard:  http://$(hostname -I | awk '{print $1}'):3000"
echo "API:        http://$(hostname -I | awk '{print $1}'):3000/api/state"
echo "Health:     http://$(hostname -I | awk '{print $1}'):3000/api/health"
echo "WebSocket:  ws://$(hostname -I | awk '{print $1}'):3000/ws"
echo ""
echo "Commands:"
echo "  pm2 logs offshore-terminal    # View logs"
echo "  pm2 monit                     # Monitor CPU/RAM"
echo "  pm2 restart offshore-terminal # Restart"
echo "  pm2 stop offshore-terminal    # Stop"
echo ""

# 9. Optional: Caddy reverse proxy
read -p "Set up Caddy HTTPS reverse proxy? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    if ! command -v caddy &> /dev/null; then
        echo "Installing Caddy..."
        sudo apt install -y debian-keyring debian-archive-keyring apt-transport-https
        curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | sudo gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
        curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | sudo tee /etc/apt/sources.list.d/caddy-stable.list
        sudo apt update
        sudo apt install -y caddy
    fi

    read -p "Enter your domain (e.g., offshore.yourdomain.com): " DOMAIN
    
    sudo tee /etc/caddy/Caddyfile > /dev/null <<EOF
$DOMAIN {
    reverse_proxy localhost:3000
}
EOF
    
    sudo systemctl restart caddy
    echo -e "${GREEN}✓ Caddy configured for https://$DOMAIN${NC}"
fi
