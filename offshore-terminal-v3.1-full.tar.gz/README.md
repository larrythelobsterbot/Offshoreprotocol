# Offshore Ops Terminal v3

ETH volatility regime monitor for Offshore Protocol. Tracks real-time ETH price movements across Binance, Bybit, and Hyperliquid to calculate operation safety scores.

## Architecture

```
┌──────────────────────────────────────────┐
│              Hetzner VPS                 │
│                                          │
│  ┌─────────┐  ┌──────────┐  ┌────────┐  │
│  │ Binance  │  │  Bybit   │  │  HL    │  │
│  │   WS     │  │   WS     │  │  REST  │  │
│  └────┬─────┘  └────┬─────┘  └───┬────┘  │
│       │              │            │       │
│       └──────┬───────┘            │       │
│              ▼                    ▼       │
│       ┌─────────────────────────────┐    │
│       │    Volatility Engine        │    │
│       │  (vol, CVD, OB, liqs,      │    │
│       │   scores, danger)          │    │
│       └──────┬──────────────────────┘    │
│              │                           │
│     ┌────────┼────────┐                  │
│     ▼        ▼        ▼                  │
│  ┌──────┐ ┌──────┐ ┌────────┐           │
│  │SQLite│ │ API  │ │Telegram│           │
│  │ data │ │server│ │ alerts │           │
│  └──────┘ └──┬───┘ └────────┘           │
│              │                           │
└──────────────┼───────────────────────────┘
               │ WS + REST
               ▼
        ┌─────────────┐
        │   Browser    │
        │  Dashboard   │
        └─────────────┘
```

## Quick Start

### 1. Transfer to VPS

```bash
rsync -avz --exclude node_modules --exclude dist --exclude data \
  ./offshore-terminal/ user@your-vps:/opt/offshore-terminal/
```

### 2. Deploy

```bash
ssh user@your-vps
cd /opt/offshore-terminal
chmod +x deploy.sh
./deploy.sh
```

### 3. Configure

```bash
cp .env.example .env
nano .env
```

Required:
- `COINGLASS_API_KEY` — Get from https://www.coinglass.com/pricing ($29/mo Hobbyist)

Optional:
- `POLYMARKET_TOKEN_ID` — ETH 5-min binary option token ID
- `TELEGRAM_BOT_TOKEN` + `TELEGRAM_CHAT_ID` — For push alerts

### 4. Access

Open `http://your-vps-ip:3000` in your browser. The dashboard auto-connects via WebSocket.

For HTTPS, run the deploy script's Caddy setup or manually configure nginx.

## API Endpoints

| Endpoint | Description |
|---|---|
| `GET /` | Dashboard UI |
| `WS /ws` | Real-time state stream (1/sec) |
| `GET /api/state` | Current snapshot |
| `GET /api/indicators?since=<ms>` | Historical indicators |
| `GET /api/indicators?from=<ms>&to=<ms>` | Indicator range |
| `GET /api/alerts?since=<ms>` | Recent alerts |
| `GET /api/stats` | Database statistics |
| `GET /api/health` | Health check |

## Data Storage

SQLite database in `data/offshore.db` stores:
- **ticks** — Price ticks from Binance (every ~100ms)
- **trades** — All trades from Binance + Bybit
- **liquidations** — Force orders from both exchanges
- **indicators** — Computed snapshots every 30 seconds
- **alerts** — All triggered alerts

Data auto-purges after 30 days (configurable via `DATA_RETENTION_DAYS`).

## Telegram Alerts

Alerts fire on:
- Danger score crossing above threshold (default 60)
- Danger score dropping below safe level (default 25)
- Critical liquidation cascade detected
- Cooldown: 15 minutes between alerts

## PM2 Commands

```bash
pm2 logs offshore-terminal     # Live logs
pm2 monit                      # CPU/RAM monitor
pm2 restart offshore-terminal  # Restart
pm2 stop offshore-terminal     # Stop
pm2 status                     # Process status
```

## Development

```bash
npm install
npm run dev    # Watch mode with tsx
```

## Next Phases

- **Phase 4 — Backtesting**: Replay historical data through the engine, validate probability calibration
- **Phase 5 — Contract Integration**: Auto-trigger operations + perp hedging
